import { Component } from '@angular/core';
import { TranslateService, TranslateModule } from '@ngx-translate/core';

@Component({
  selector: 'app-root',
  standalone: true,
  templateUrl: './app.component.html',
  styleUrl: './app.component.scss',
  imports: [TranslateModule], // Only import the pipe/template things now
})
export class AppComponent {
  constructor(private translate: TranslateService) {
    translate.addLangs(['en', 'fr', 'es', 'ar']);
    translate.setDefaultLang('en');
    translate.use('en');
  }

  switchLanguage(event: any) {
    this.translate.use(event.target.value);
  }
}
